/* original parser id follows */
/* yysccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93" */
/* (use YYMAJOR/YYMINOR for ifdefs dependent on parser version) */

#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define YYPATCH 20141006

#define YYEMPTY        (-1)
#define yyclearin      (yychar = YYEMPTY)
#define yyerrok        (yyerrflag = 0)
#define YYRECOVERING() (yyerrflag != 0)
#define YYENOMEM       (-2)
#define YYEOF          0
#define YYPREFIX "yy"

#define YYPURE 0


/*
 * (C) Copyright 2014, Stephen M. Cameron.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 2 as
 *  published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

struct parser_value_type {
	double dval;
	long long ival;
	int has_dval;
	int has_error;
};

typedef union valtype {
	struct parser_value_type v;
} PARSER_VALUE_TYPE;

#define YYSTYPE PARSER_VALUE_TYPE

int yyerror(__attribute__((unused)) long long *result,
		__attribute__((unused)) double *dresult,
		__attribute__((unused)) int *has_error,
		__attribute__((unused)) int *units_specified,
		__attribute__((unused)) const char *msg);

extern int yylex(void);
extern void yyrestart(FILE *file);
extern int lexer_value_is_time;

#ifdef YYSTYPE
#undef  YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
#endif
#ifndef YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
typedef union valtype {
	struct parser_value_type {
		double dval;
		long long ival;
		int has_dval;
		int has_error;
	} v;
} YYSTYPE;
#endif /* !YYSTYPE_IS_DECLARED */

/* compatibility with bison */
#ifdef YYPARSE_PARAM
/* compatibility with FreeBSD */
# ifdef YYPARSE_PARAM_TYPE
#  define YYPARSE_DECL() yyparse(YYPARSE_PARAM_TYPE YYPARSE_PARAM)
# else
#  define YYPARSE_DECL() yyparse(void *YYPARSE_PARAM)
# endif
#else
# define YYPARSE_DECL() yyparse(long long *result, double *dresult, int *has_error, int *units_specified)
#endif

/* Parameters sent to lex. */
#ifdef YYLEX_PARAM
# define YYLEX_DECL() yylex(void *YYLEX_PARAM)
# define YYLEX yylex(YYLEX_PARAM)
#else
# define YYLEX_DECL() yylex(void)
# define YYLEX yylex()
#endif

/* Parameters sent to yyerror. */
#ifndef YYERROR_DECL
#define YYERROR_DECL() yyerror(long long *result, double *dresult, int *has_error, int *units_specified, const char *s)
#endif
#ifndef YYERROR_CALL
#define YYERROR_CALL(msg) yyerror(result, dresult, has_error, units_specified, msg)
#endif

extern int YYPARSE_DECL();

#define NUMBER 257
#define BYE 258
#define SUFFIX 259
#define UMINUS 260
#define YYERRCODE 256
typedef int YYINT;
static const YYINT yylhs[] = {                           -1,
    0,    0,    1,    1,    1,    1,    1,    1,    1,    1,
    1,    1,
};
static const YYINT yylen[] = {                            2,
    1,    2,    3,    3,    3,    3,    2,    3,    2,    3,
    3,    1,
};
static const YYINT yydefred[] = {                         0,
   12,    0,    0,    0,    0,    7,    0,    2,    9,    0,
    0,    0,    0,    0,    0,    8,    0,    0,    0,    0,
    0,   10,
};
static const YYINT yydgoto[] = {                          4,
    5,
};
static const YYINT yysindex[] = {                       -40,
    0,  -40,  -40,    0,  -21,    0,  -12,    0,    0,  -40,
  -40,  -40,  -40,  -40,  -40,    0,  -35,  -35,  -27,  -27,
  -27,    0,
};
static const YYINT yyrindex[] = {                         0,
    0,    0,    0,    0,    3,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,   20,   23,    1,    8,
   15,    0,
};
static const YYINT yygindex[] = {                         0,
   73,
};
#define YYTABLESIZE 279
static const YYINT yytable[] = {                          3,
    5,   15,    1,    0,    2,    0,   12,    6,    0,   15,
    0,   13,    0,    0,   11,   15,    0,    0,    0,    4,
   12,   11,    3,   10,   15,   13,    0,    0,   16,   12,
   11,    0,   10,    0,   13,    0,    0,    0,    0,    0,
    0,    5,    5,    5,    0,    5,    0,    5,    6,    6,
    6,    0,    6,    0,    6,   11,   11,   11,   14,   11,
    4,   11,    4,    3,    4,    3,   14,    3,    0,    0,
    0,    0,   14,    0,    6,    7,    0,    0,    0,    0,
    0,   14,   17,   18,   19,   20,   21,   22,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    1,    0,    0,    0,
    0,    0,    0,    9,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    8,    0,    0,    9,    0,    0,
    0,    0,    0,    0,    0,    0,    9,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    5,    0,    0,    5,
    0,    0,    0,    6,    0,    0,    6,    0,    0,    0,
   11,    0,    0,   11,    0,    4,    0,    0,    3,
};
static const YYINT yycheck[] = {                         40,
    0,   37,    0,   -1,   45,   -1,   42,    0,   -1,   37,
   -1,   47,   -1,   -1,    0,   37,   -1,   -1,   -1,    0,
   42,   43,    0,   45,   37,   47,   -1,   -1,   41,   42,
   43,   -1,   45,   -1,   47,   -1,   -1,   -1,   -1,   -1,
   -1,   41,   42,   43,   -1,   45,   -1,   47,   41,   42,
   43,   -1,   45,   -1,   47,   41,   42,   43,   94,   45,
   41,   47,   43,   41,   45,   43,   94,   45,   -1,   -1,
   -1,   -1,   94,   -1,    2,    3,   -1,   -1,   -1,   -1,
   -1,   94,   10,   11,   12,   13,   14,   15,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,  257,   -1,   -1,   -1,
   -1,   -1,   -1,  259,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,  256,   -1,   -1,  259,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,  259,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,  256,   -1,   -1,  259,
   -1,   -1,   -1,  256,   -1,   -1,  259,   -1,   -1,   -1,
  256,   -1,   -1,  259,   -1,  256,   -1,   -1,  256,
};
#define YYFINAL 4
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 260
#define YYUNDFTOKEN 264
#define YYTRANSLATE(a) ((a) > YYMAXTOKEN ? YYUNDFTOKEN : (a))
#if YYDEBUG
static const char *const yyname[] = {

"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,"'%'",0,0,"'('","')'","'*'","'+'",0,"'-'",0,"'/'",0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"'^'",0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
"NUMBER","BYE","SUFFIX","UMINUS",0,0,0,"illegal-symbol",
};
static const char *const yyrule[] = {
"$accept : top_level",
"top_level : expression",
"top_level : expression error",
"expression : expression '+' expression",
"expression : expression '-' expression",
"expression : expression '*' expression",
"expression : expression '/' expression",
"expression : '-' expression",
"expression : '(' expression ')'",
"expression : expression SUFFIX",
"expression : expression '%' expression",
"expression : expression '^' expression",
"expression : NUMBER",

};
#endif

int      yydebug;
int      yynerrs;

int      yyerrflag;
int      yychar;
YYSTYPE  yyval;
YYSTYPE  yylval;

/* define the initial stack-sizes */
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH  YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 10000
#define YYMAXDEPTH  10000
#endif
#endif

#define YYINITSTACKSIZE 200

typedef struct {
    unsigned stacksize;
    YYINT    *s_base;
    YYINT    *s_mark;
    YYINT    *s_last;
    YYSTYPE  *l_base;
    YYSTYPE  *l_mark;
} YYSTACKDATA;
/* variables for the parser stack */
static YYSTACKDATA yystack;
#include <stdio.h>

/* Urgh.  yacc and lex are kind of horrible.  This is not thread safe, obviously. */
static int lexer_read_offset = 0;
static char lexer_input_buffer[1000];

int lexer_input(char* buffer, unsigned int *bytes_read, int bytes_requested)
{
	int bytes_left = strlen(lexer_input_buffer) - lexer_read_offset;

	if (bytes_requested > bytes_left )
		bytes_requested = bytes_left;
	memcpy(buffer, &lexer_input_buffer[lexer_read_offset], bytes_requested);
	*bytes_read = bytes_requested;
	lexer_read_offset += bytes_requested;
	return 0;
}

static void setup_to_parse_string(const char *string)
{
	unsigned int len;

	len = strlen(string);
	if (len > sizeof(lexer_input_buffer) - 3)
		len = sizeof(lexer_input_buffer) - 3;

	strncpy(lexer_input_buffer, string, len);
	lexer_input_buffer[len] = '\0'; 
	lexer_input_buffer[len + 1] = '\0';  /* lex/yacc want string double null terminated! */
	lexer_read_offset = 0;
}

int evaluate_arithmetic_expression(const char *buffer, long long *ival, double *dval,
					double implied_units, int is_time)
{
	int rc, units_specified = 0, has_error = 0;

	lexer_value_is_time = is_time;
	setup_to_parse_string(buffer);
	rc = yyparse(ival, dval, &has_error, &units_specified);
	yyrestart(NULL);
	if (rc || has_error) {
		*ival = 0;
		*dval = 0;
		has_error = 1;
	}
	if (!units_specified) {
		*ival = (int) ((double) *ival * implied_units);
		*dval = *dval * implied_units;
	}
	return has_error;
}

int yyerror(__attribute__((unused)) long long *result,
		__attribute__((unused)) double *dresult,
		__attribute__((unused)) int *has_error,
		__attribute__((unused)) int *units_specified,
		__attribute__((unused)) const char *msg)
{
	/* We do not need to do anything here. */
	return 0;
}


#if YYDEBUG
#include <stdio.h>		/* needed for printf */
#endif

#include <stdlib.h>	/* needed for malloc, etc */
#include <string.h>	/* needed for memset */

/* allocate initial stack or double stack size, up to YYMAXDEPTH */
static int yygrowstack(YYSTACKDATA *data)
{
    int i;
    unsigned newsize;
    YYINT *newss;
    YYSTYPE *newvs;

    if ((newsize = data->stacksize) == 0)
        newsize = YYINITSTACKSIZE;
    else if (newsize >= YYMAXDEPTH)
        return YYENOMEM;
    else if ((newsize *= 2) > YYMAXDEPTH)
        newsize = YYMAXDEPTH;

    i = (int) (data->s_mark - data->s_base);
    newss = (YYINT *)realloc(data->s_base, newsize * sizeof(*newss));
    if (newss == 0)
        return YYENOMEM;

    data->s_base = newss;
    data->s_mark = newss + i;

    newvs = (YYSTYPE *)realloc(data->l_base, newsize * sizeof(*newvs));
    if (newvs == 0)
        return YYENOMEM;

    data->l_base = newvs;
    data->l_mark = newvs + i;

    data->stacksize = newsize;
    data->s_last = data->s_base + newsize - 1;
    return 0;
}

#if YYPURE || defined(YY_NO_LEAKS)
static void yyfreestack(YYSTACKDATA *data)
{
    free(data->s_base);
    free(data->l_base);
    memset(data, 0, sizeof(*data));
}
#else
#define yyfreestack(data) /* nothing */
#endif

#define YYABORT  goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR  goto yyerrlab

int
YYPARSE_DECL()
{
    int yym, yyn, yystate;
#if YYDEBUG
    const char *yys;

    if ((yys = getenv("YYDEBUG")) != 0)
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = YYEMPTY;
    yystate = 0;

#if YYPURE
    memset(&yystack, 0, sizeof(yystack));
#endif

    if (yystack.s_base == NULL && yygrowstack(&yystack) == YYENOMEM) goto yyoverflow;
    yystack.s_mark = yystack.s_base;
    yystack.l_mark = yystack.l_base;
    yystate = 0;
    *yystack.s_mark = 0;

yyloop:
    if ((yyn = yydefred[yystate]) != 0) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = YYLEX) < 0) yychar = YYEOF;
#if YYDEBUG
        if (yydebug)
        {
            yys = yyname[YYTRANSLATE(yychar)];
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack) == YYENOMEM)
        {
            goto yyoverflow;
        }
        yystate = yytable[yyn];
        *++yystack.s_mark = yytable[yyn];
        *++yystack.l_mark = yylval;
        yychar = YYEMPTY;
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;

    YYERROR_CALL("syntax error");

    goto yyerrlab;

yyerrlab:
    ++yynerrs;

yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yystack.s_mark]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yystack.s_mark, yytable[yyn]);
#endif
                if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack) == YYENOMEM)
                {
                    goto yyoverflow;
                }
                yystate = yytable[yyn];
                *++yystack.s_mark = yytable[yyn];
                *++yystack.l_mark = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yystack.s_mark);
#endif
                if (yystack.s_mark <= yystack.s_base) goto yyabort;
                --yystack.s_mark;
                --yystack.l_mark;
            }
        }
    }
    else
    {
        if (yychar == YYEOF) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = yyname[YYTRANSLATE(yychar)];
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = YYEMPTY;
        goto yyloop;
    }

yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    if (yym)
        yyval = yystack.l_mark[1-yym];
    else
        memset(&yyval, 0, sizeof yyval);
    switch (yyn)
    {
case 1:
	{
				*result = yystack.l_mark[0].v.ival;
				*dresult = yystack.l_mark[0].v.dval;
				*has_error = yystack.l_mark[0].v.has_error;
			}
break;
case 2:
	{
				*result = yystack.l_mark[-1].v.ival;
				*dresult = yystack.l_mark[-1].v.dval;
				*has_error = 1;
			}
break;
case 3:
	{ 
			if (!yystack.l_mark[-2].v.has_dval && !yystack.l_mark[0].v.has_dval)
				yyval.v.ival = yystack.l_mark[-2].v.ival + yystack.l_mark[0].v.ival;
			else
				yyval.v.ival = (long long) (yystack.l_mark[-2].v.dval + yystack.l_mark[0].v.dval);
			yyval.v.dval = yystack.l_mark[-2].v.dval + yystack.l_mark[0].v.dval;
			yyval.v.has_error = yystack.l_mark[-2].v.has_error || yystack.l_mark[0].v.has_error;
		}
break;
case 4:
	{
			if (!yystack.l_mark[-2].v.has_dval && !yystack.l_mark[0].v.has_dval)
				yyval.v.ival = yystack.l_mark[-2].v.ival - yystack.l_mark[0].v.ival; 
			else
				yyval.v.ival = (long long) (yystack.l_mark[-2].v.dval - yystack.l_mark[0].v.dval); 
			yyval.v.dval = yystack.l_mark[-2].v.dval - yystack.l_mark[0].v.dval; 
			yyval.v.has_error = yystack.l_mark[-2].v.has_error || yystack.l_mark[0].v.has_error;
		}
break;
case 5:
	{
			if (!yystack.l_mark[-2].v.has_dval && !yystack.l_mark[0].v.has_dval)
				yyval.v.ival = yystack.l_mark[-2].v.ival * yystack.l_mark[0].v.ival;
			else
				yyval.v.ival = (long long) (yystack.l_mark[-2].v.dval * yystack.l_mark[0].v.dval);
			yyval.v.dval = yystack.l_mark[-2].v.dval * yystack.l_mark[0].v.dval;
			yyval.v.has_error = yystack.l_mark[-2].v.has_error || yystack.l_mark[0].v.has_error;
		}
break;
case 6:
	{
			if (yystack.l_mark[0].v.ival == 0)
				yyerror(0, 0, 0, 0, "divide by zero");
			else
				yyval.v.ival = yystack.l_mark[-2].v.ival / yystack.l_mark[0].v.ival;
			if (yystack.l_mark[0].v.dval < 1e-20 && yystack.l_mark[0].v.dval > -1e-20)
				yyerror(0, 0, 0, 0, "divide by zero");
			else
				yyval.v.dval = yystack.l_mark[-2].v.dval / yystack.l_mark[0].v.dval;
			if (yystack.l_mark[0].v.has_dval || yystack.l_mark[-2].v.has_dval)
				yyval.v.ival = (long long) yyval.v.dval;
			yyval.v.has_error = yystack.l_mark[-2].v.has_error || yystack.l_mark[0].v.has_error;
		}
break;
case 7:
	{
			yyval.v.ival = -yystack.l_mark[0].v.ival;
			yyval.v.dval = -yystack.l_mark[0].v.dval;
			yyval.v.has_error = yystack.l_mark[0].v.has_error;
		}
break;
case 8:
	{ yyval.v = yystack.l_mark[-1].v; }
break;
case 9:
	{
			if (!yystack.l_mark[-1].v.has_dval && !yystack.l_mark[0].v.has_dval)
				yyval.v.ival = yystack.l_mark[-1].v.ival * yystack.l_mark[0].v.ival;
			else
				yyval.v.ival = (long long) yystack.l_mark[-1].v.dval * yystack.l_mark[0].v.dval;
			if (yystack.l_mark[-1].v.has_dval || yystack.l_mark[0].v.has_dval)
				yyval.v.dval = yystack.l_mark[-1].v.dval * yystack.l_mark[0].v.dval;
			else
				yyval.v.dval = yystack.l_mark[-1].v.ival * yystack.l_mark[0].v.ival;
			yyval.v.has_error = yystack.l_mark[-1].v.has_error || yystack.l_mark[0].v.has_error;
			*units_specified = 1;
		}
break;
case 10:
	{
			if (yystack.l_mark[-2].v.has_dval || yystack.l_mark[0].v.has_dval)
				yyerror(0, 0, 0, 0, "modulo on floats");
			if (yystack.l_mark[0].v.ival == 0)
				yyerror(0, 0, 0, 0, "divide by zero");
			else {
				yyval.v.ival = yystack.l_mark[-2].v.ival % yystack.l_mark[0].v.ival;
				yyval.v.dval = yyval.v.ival;
			}
			yyval.v.has_error = yystack.l_mark[-2].v.has_error || yystack.l_mark[0].v.has_error;
		}
break;
case 11:
	{
			yyval.v.has_error = yystack.l_mark[-2].v.has_error || yystack.l_mark[0].v.has_error;
			if (!yystack.l_mark[-2].v.has_dval && !yystack.l_mark[0].v.has_dval) {
				int i;

				if (yystack.l_mark[0].v.ival == 0) {
					yyval.v.ival = 1;
				} else if (yystack.l_mark[0].v.ival > 0) {
					long long tmp = yystack.l_mark[-2].v.ival;
					yyval.v.ival = 1.0;
					for (i = 0; i < yystack.l_mark[0].v.ival; i++)
						yyval.v.ival *= tmp;
				}  else {
					/* integers, 2^-3, ok, we now have doubles */
					double tmp;
					if (yystack.l_mark[-2].v.ival == 0 && yystack.l_mark[0].v.ival == 0) {
						tmp = 1.0;
						yyval.v.has_error = 1;
					} else {
						double x = (double) yystack.l_mark[-2].v.ival;
						double y = (double) yystack.l_mark[0].v.ival;
						tmp = pow(x, y);
					}
					yyval.v.ival = (long long) tmp;
				}
				yyval.v.dval = pow(yystack.l_mark[-2].v.dval, yystack.l_mark[0].v.dval);
			} else {
				yyval.v.dval = pow(yystack.l_mark[-2].v.dval, yystack.l_mark[0].v.dval);
				yyval.v.ival = (long long) yyval.v.dval;
			}
		}
break;
case 12:
	{ yyval.v = yystack.l_mark[0].v; }
break;
    }
    yystack.s_mark -= yym;
    yystate = *yystack.s_mark;
    yystack.l_mark -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yystack.s_mark = YYFINAL;
        *++yystack.l_mark = yyval;
        if (yychar < 0)
        {
            if ((yychar = YYLEX) < 0) yychar = YYEOF;
#if YYDEBUG
            if (yydebug)
            {
                yys = yyname[YYTRANSLATE(yychar)];
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == YYEOF) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yystack.s_mark, yystate);
#endif
    if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack) == YYENOMEM)
    {
        goto yyoverflow;
    }
    *++yystack.s_mark = (YYINT) yystate;
    *++yystack.l_mark = yyval;
    goto yyloop;

yyoverflow:
    YYERROR_CALL("yacc stack overflow");

yyabort:
    yyfreestack(&yystack);
    return (1);

yyaccept:
    yyfreestack(&yystack);
    return (0);
}
