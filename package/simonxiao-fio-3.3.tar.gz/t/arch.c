#include "../arch/arch.h"

unsigned long arch_flags = 0;
bool tsc_reliable;
int arch_random;
